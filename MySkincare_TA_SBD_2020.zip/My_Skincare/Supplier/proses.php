<?php
require_once "../_config/config.php";

if(isset($_POST['Add'])){
    $id_supplier = trim(mysqli_real_escape_string($con, $_POST['id_supplier']));
    $nama_supplier = trim(mysqli_real_escape_string($con, $_POST['nama_supplier']));
    $alamat_supplier = trim(mysqli_real_escape_string($con, $_POST['alamat_supplier']));
 
    mysqli_query($con, "INSERT INTO tb_supplier (id_supplier, nama_supplier, alamat_supplier) VALUES ('$id_supplier', '$nama_supplier', '$alamat_supplier')") or die (mysqli_error($con));
    echo"<script>window.location='data.php'</script>";

} else if(isset($_POST['edit'])){
    $id = $_POST['id'];
    $nama_supplier = trim(mysqli_real_escape_string($con, $_POST['nama_supplier']));
    $alamat_supplier = trim(mysqli_real_escape_string($con, $_POST['alamat_supplier']));
    
    mysqli_query($con, "UPDATE tb_supplier SET nama_supplier ='$nama_supplier', alamat_supplier = '$alamat_supplier' WHERE id_supplier='$id'") or die (mysqli_error($con));

    echo "<script>window.location='data.php' </script>";
}
?>