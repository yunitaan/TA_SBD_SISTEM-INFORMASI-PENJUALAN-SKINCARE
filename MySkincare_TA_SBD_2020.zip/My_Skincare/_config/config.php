<?php
session_start();
//koneksi
$con = mysqli_connect('localhost', 'root', '', 'My_Skincare');
if (mysqli_connect_errno()){
    echo mysqli_connect_error();
}
//fungsi base_url
function base_url($url = null){
    $base_url = "http://localhost/My_Skincare";
    if($url != null){
        return $base_url ."/".$url;
    } else {
        return $base_url;}
}
?>