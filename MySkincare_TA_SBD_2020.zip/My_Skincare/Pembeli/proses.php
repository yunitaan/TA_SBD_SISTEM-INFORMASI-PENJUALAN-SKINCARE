<?php
require_once "../_config/config.php";

if(isset($_POST['Add'])){
    $id_pembeli = trim(mysqli_real_escape_string($con, $_POST['id_pembeli']));
    $nama_pembeli = trim(mysqli_real_escape_string($con, $_POST['nama_pembeli']));
    $id_barang = trim(mysqli_real_escape_string($con, $_POST['id_barang']));
    $telp_pembeli = trim(mysqli_real_escape_string($con, $_POST['telp_pembeli']));
    $alamat_pembeli = trim(mysqli_real_escape_string($con, $_POST['alamat_pembeli']));
 
    mysqli_query($con, "INSERT INTO tb_pembeli (Id_pembeli, Nama_pembeli, id_barang, telp_pembeli, alamat_pembeli) VALUES ('$Id_pembeli', '$Nama_pembeli', '$Id_pembeli','$telp_pembeli', '$alamat_pembeli')") or die (mysqli_error($con));
    echo"<script>window.location='data.php'</script>";

} else if(isset($_POST['edit'])){
    $id = $_POST['id'];
    $nama_pembeli = trim(mysqli_real_escape_string($con, $_POST['nama_pembeli']));
    $id_barang = trim(mysqli_real_escape_string($con, $_POST['id_barang']));
    $telp_pembeli = trim(mysqli_real_escape_string($con, $_POST['telp_pembeli']));
    $alamat_pembeli = trim(mysqli_real_escape_string($con, $_POST['alamat_pembeli']));
    
    mysqli_query($con, "UPDATE tb_pembeli SET nama_pembeli ='$nama_pembeli', id_barang ='$id_barang', telp_pembeli ='$telp_pembeli', 
    alamat_pembeli = '$alamat_pembeli' WHERE id_pembeli ='$id'") or die (mysqli_error($con));

    echo "<script>window.location='data.php' </script>";
}
?>