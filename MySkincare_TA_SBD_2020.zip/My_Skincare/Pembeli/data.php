<?php include_once('../_header.php'); ?>
<div class="box">
    <h1>Pembeli</h1>
    <h4>
        <small> Pembeli</small>
        <div class="pull-right">
            <a href="" class="btn btn-default btn-xs"><i class="glyphicon glyphicon-refresh"></i></a>
            <a href="add.php" class="btn btn-succes btn-xs"><i class="glyphicon glyphicon-plus"></i>Tambahkan Barang</a>
</div>
        </h4>

<div style="margin-bottom: 20px;">
   <form class="form-inline" action="" method="post">
       <div class= "form-group">
           <input type="text" name="pencarian" class="form-control" placeholder="Pencarian">
       </div>
       <div class="form-group">
           <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
        </div>
    </form>
</div>
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Id Pembeli</th>
                    <th>Nama Pembeli</th>
                    <th>Id Barang</th>
                    <th>Telepon Pembeli</th>
                    <th>Alamat Pembeli</th>
                    <th><i class="glyphicon glyphicon-cog"></i></th>
                    </tr>
            </thead>
            <tbody>
                        <?php
                        $batas = 6;
                        $hal = @$_GET['hal'];
                        if(empty($hal)){
                            $posisi = 0;
                            $hal = 1;
                        } else{
                            $posisi = ($hal -1)*$batas;
                        }
                        $no=1;
                        if($_SERVER['REQUEST_METHOD']=="POST"){
                            $pencarian =trim(mysqli_real_escape_string($con,@$_POST['pencarian']));
                            if($pencarian!= ''){
                                $sql = "SELECT*FROM tb_pembeli WHERE nama_pembeli LIKE '%$pencarian%'";
                                $query = $sql;
                                $queryJml = $sql;
                            } else {
                                $query = "SELECT * FROM tb_pembeli LIMIT $posisi, $batas";
                                $queryJml = "SELECT * FROM tb_pembeli";
                                $no= $posisi + 1; 
                            }

                            } else {
                                $query = "SELECT * FROM tb_pembeli LIMIT $posisi, $batas";
                                $queryJml = "SELECT* FROM tb_pembeli";
                                $no= $posisi + 1; 
                            }
                        
                        
                        $sql_Barang = mysqli_query($con, $query) or die (mysqli_error($con));
                        if(mysqli_num_rows($sql_Barang)>0){
                                while($data = mysqli_fetch_array($sql_Barang)) { ?>
                                    <tr>
                           
                                        <td><?=$data['id_pembeli']?></td>
                                        <td><?=$data['nama_pembeli']?></td>
                                        <td><?=$data['id_barang']?></td>
                                        <td><?=$data['telp_pembeli']?></td>
                                        <td><?=$data['alamat_pembeli']?></td>
                                        <td class="text-center">
                                        <a href="edit.php?id=<?=$data['id_pembeli']?>" class="btn btn-warning btn-xs"><i class="glyphicon glyphicon-edit"></i></a>
                                        <a href="delete.php?id=<?=$data['id_pembeli']?>" onclick="return confirm('Yakin Akan Menghapus?')" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i></a>
                                        </td>
                                    </tr>

                                    <?php
                                }
                        } else {
                            echo "<tr><td colspan=\"4\" align =\"center\">Data tidak ditemukan</td></tr>";
                        }
                        ?>
                        </tbody>
                  </table>
    </div>
    <?php
    if( @$_POST['pencarian'] =='') {  ?>
        <div style= "float:left;">
        <?php
        $jml = mysqli_num_rows(mysqli_query($con, $queryJml));
        echo"Data Hasil Pencarian: <b>$jml</b>";
        ?>
</div>

<?php
    }
    ?>
    </div>

<?php include_once('../_footer.php'); ?>