<?php include_once('../_header.php');
 ?>
    <div class ="box">
        <h1>Barang<h1>
        <h4>
            <small>Tambah Data Barang</small>
                <div class="pull-right">                
                <a href="data.php" class="btn btn-warning btn-xs"><i class="glyphicon glyphicon-chevron-left"></i>Kembali</a>
                </div>
            <h4>
            <div class="row">
            <div class ="col-lg-6 col-lg-offset-3">
                <form action="proses.php" method="post">
                    <div class = "form-group">
                        <label for="nama_barang">Nama Barang</label>
                        <input type="text" name="nama_barang" id="nama_barang" class="form-control" required autofocus>
                    </div>
                    <div class = "form-group">
                        <label for="harga_barang">Harga Barang</label>
                        <input type="text" name="harga_barang" id="harga_barang" class="form-control">
                    </div>
                    <div class = "form-group">
                        <label for="stok_barang">Stok Barang</label>
                        <input type="text" name="stok_barang" id="stok_barang" class="form-control">
                    </div>
                    <div class = "form-group">
                        <label for="kadaluarsa_barang">Kadaluarsa Barang</label>
                        <input type="date" name="kadaluarsa_barang" id="kadaluarsa_barang" class="form-control">
                    </div>
                    <div class = "form-group">
                        <label for="id_supplier">Id Supplier</label>
                        <input type="text" name="id_supplier" id="id_supplier" class="form-control">
                    </div>
                        <div lass="form-group">
                            <input type="submit" name="Add" value="Simpan" class="btn btn-succes">
                    </div>
                </form>
            </div>    
        </div>
    </div>
<?php include_once('../_footer.php');?>