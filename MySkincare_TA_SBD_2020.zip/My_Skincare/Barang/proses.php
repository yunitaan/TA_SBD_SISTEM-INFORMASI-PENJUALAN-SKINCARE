<?php
require_once "../_config/config.php";

if(isset($_POST['Add'])){
    $id_barang = trim(mysqli_real_escape_string($con, $_POST['id_barang']));
    $nama_barang = trim(mysqli_real_escape_string($con, $_POST['nama_barang']));
    $harga_barang = trim(mysqli_real_escape_string($con, $_POST['harga_barang']));
    $stok_barang = trim(mysqli_real_escape_string($con, $_POST['stok_barang']));
    $kadaluarsa_barang = trim(mysqli_real_escape_string($con, $_POST['kadaluarsa_barang']));
    $id_supplier = trim(mysqli_real_escape_string($con, $_POST['id_supplier']));
 
    mysqli_query($con, "INSERT INTO tb_barang (id_barang, nama_barang, harga_barang, stok_barang, kadaluarsa_barang, id_supplier) VALUES ('$id_barang', '$nama_barang', '$harga_barang','$stok_barang', '$kadaluarsa_barang','$id_supplier')") or die (mysqli_error($con));
    echo"<script>window.location='data.php'</script>";

} else if(isset($_POST['edit'])){
    $id = $_POST['id'];
    $nama_barang = trim(mysqli_real_escape_string($con, $_POST['nama_barang']));
    $harga_barang = trim(mysqli_real_escape_string($con, $_POST['harga_barang']));
    $stok_barang = trim(mysqli_real_escape_string($con, $_POST['stok_barang']));
    $kadaluarsa_barang = trim(mysqli_real_escape_string($con, $_POST['kadaluarsa_barang']));
    $id_supplier = trim(mysqli_real_escape_string($con, $_POST['id_supplier']));
    mysqli_query($con, "UPDATE tb_barang SET nama_barang ='$nama_barang', harga_barang ='$harga_barang', stok_barang ='$stok_barang', 
    kadaluarsa_barang = '$kadaluarsa_barang', id_supplier ='$id_supplier' WHERE id_barang ='$id'") or die (mysqli_error($con));
    echo "<script>window.location='data.php'</script>";
}
?>