<?php include_once('../_header.php');
 ?>
    <div class ="box">
        <h1>Barang<h1>
        <h4>
            <small>Edit Data Barang</small>
                <div class="pull-right">                
                <a href="data.php" class="btn btn-warning btn-xs"><i class="glyphicon glyphicon-chevron-left"></i>Kembali</a>
                </div>
        <h4>
            <div class="row">
                <div class ="col-lg-6 col-lg-offset-3">
                <?php
                $id = @$_GET['id'];
                $sql_barang = mysqli_query ($con, "SELECT*FROM tb_barang WHERE id_barang = '$id'") or die (mysqli_error($con));
                $data = mysqli_fetch_array($sql_barang);
                ?>
                    <form action="proses.php" method="post">
                        <div class = "form-group">
                            <label for="nama_barang">Nama Barang</label>
                            <input type ="hidden" name="id" value="<?=$data['id_barang']?>">
                            <input type="text" name="nama_barang" id="nama_barang" value="<?=$data['nama_barang']?>"  class="form-control" required autofocus>
                        </div>
                        <div class = "form-group">
                            <label for="harga_barang">Harga barang</label>
                            <input type="text" name="harga_barang" id="harga_barang" value="<?=$data['harga_barang']?>"   class="form-control">
                        </div>
                        <div class = "form-group">
                            <label for="stok_barang">Stok barang</label>
                            <input type="text" name="stok_barang" id="stok_barang" value="<?=$data['stok_barang']?>"  class="form-control">
                        </div>
                        <div class = "form-group">
                            <label for="kadaluarsa_barang">Kadaluarsa barang</label>
                            <input type="date" name="kadaluarsa_barang" id="kadaluarsa_barang" value="<?=$data['kadaluarsa_barang']?>"  class="form-control">
                        </div>
                        <div class = "form-group">
                            <label for="id_supplier">Id supplier</label>
                            <input type="text" name="id_supplier" id="id_supplier" value="<?=$data['id_supplier']?>"  class="form-control">
                        </div>
                        
                        <div class="form-group pull-right">
                            <input type="submit" name="edit" value="Simpan" class="btn btn-success">
                    </div>
                    </form>
                </div>    
            </div>
    </div>
<?php include_once('../_footer.php');?>